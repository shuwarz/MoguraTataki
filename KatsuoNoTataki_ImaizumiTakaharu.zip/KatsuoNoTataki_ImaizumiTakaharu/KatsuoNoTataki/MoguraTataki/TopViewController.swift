//
//  ViewController.swift
//  MoguraTataki
//
//  Created by 今泉　孝陽 on 2020/06/05.
//  Copyright © 2020 app.com.Takaharu.Imaizumi. All rights reserved.
//

import UIKit

class TopViewController: UIViewController {

    @IBOutlet var label: UILabel!
    
    override func viewDidLoad() {
           super.viewDidLoad()
            // Do any additional setup after loading the view.
        navigationController?.setNavigationBarHidden(true, animated: false)
        
    }

    @IBAction func start() {
        
    }
    
    @IBAction func stop() {
        
    }
    
    
}

        
